import React, { useState } from 'react';

// Mock data for subscription plans - replace with API calls or configuration
const plans = [
  {
    id: 'free',
    name: 'Plano Gratuito',
    price: 0,
    features: ['Até 5 agendamentos/mês', 'Suporte básico por e-mail'],
    current: true, // Assuming the user is currently on the free plan
  },
  {
    id: 'premium',
    name: 'Plano Premium',
    price: 29.90,
    features: ['Agendamentos ilimitados', 'Suporte prioritário', 'Relatórios avançados'],
    current: false,
  },
  {
    id: 'pro',
    name: 'Plano Pro',
    price: 59.90,
    features: ['Todos os recursos Premium', 'Multi-usuário', 'API de integração'],
    current: false,
  },
];

const UpgradePlanPage: React.FC = () => {
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);

  const handleSelectPlan = (planId: string) => {
    setSelectedPlanId(planId);
    // Here you would typically redirect to a Stripe checkout page or similar
    // For this example, we'll just log it and show an alert.
    const selected = plans.find(p => p.id === planId);
    if (selected) {
      alert(`Você selecionou o ${selected.name}. Prossiga para o pagamento (simulado).`);
      console.log(`User selected plan: ${selected.name}`);
    }
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-pink-600 mb-8 text-center">Escolha seu Plano</h1>
        <p className="text-center text-gray-600 mb-10">
          Atualize seu plano para desbloquear mais funcionalidades e levar a gestão do seu salão para o próximo nível.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div 
              key={plan.id} 
              className={`border-2 rounded-lg p-6 flex flex-col justify-between transition-all duration-300 ease-in-out transform hover:scale-105 
                          ${plan.current ? 'border-pink-500 bg-pink-50 shadow-lg' : 'border-gray-300 hover:border-pink-400'}
                          ${selectedPlanId === plan.id && !plan.current ? 'ring-4 ring-pink-500 ring-offset-2' : ''}`}
            >
              <div>
                <h2 className={`text-2xl font-semibold mb-3 ${plan.current ? 'text-pink-700' : 'text-gray-800'}`}>{plan.name}</h2>
                <p className={`text-4xl font-bold mb-4 ${plan.current ? 'text-pink-600' : 'text-pink-500'}`}>
                  R${plan.price.toFixed(2)}<span className="text-base font-normal">/mês</span>
                </p>
                <ul className="space-y-2 mb-6 text-sm text-gray-600">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <svg className={`w-4 h-4 mr-2 ${plan.current ? 'text-pink-500' : 'text-green-500'}`} fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              <button 
                onClick={() => handleSelectPlan(plan.id)}
                disabled={plan.current}
                className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors duration-300 
                            ${plan.current 
                              ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                              : 'bg-pink-600 hover:bg-pink-700 text-white focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2'}
                          `}
              >
                {plan.current ? 'Plano Atual' : plan.id === 'free' ? 'Continuar Grátis' : 'Selecionar Plano'}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600">Dúvidas? <a href="/contact-support" className="text-pink-500 hover:underline">Fale com o suporte</a>.</p>
        </div>
      </div>
    </div>
  );
};

export default UpgradePlanPage;

