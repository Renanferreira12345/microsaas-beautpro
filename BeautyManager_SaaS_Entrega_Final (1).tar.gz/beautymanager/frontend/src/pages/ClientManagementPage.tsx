import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockClients = [
  { id: 1, name: 'Ana Silva', phone: '11999998888', email: 'ana.silva@example.com', lastVisit: '2024-04-15', totalSpent: 350.00 },
  { id: 2, name: 'Bruno Costa', phone: '21988887777', email: 'bruno.costa@example.com', lastVisit: '2024-05-01', totalSpent: 120.50 },
  { id: 3, name: 'Carla Dias', phone: '31977776666', email: 'carla.dias@example.com', lastVisit: '2024-03-20', totalSpent: 500.75 },
];

const ClientManagementPage: React.FC = () => {
  const [clients, setClients] = useState(mockClients);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [currentClient, setCurrentClient] = useState<any>(null); // Replace 'any' with a Client interface

  // TODO: Fetch clients from API on component mount
  // useEffect(() => {
  //   // fetchClients();
  // }, []);

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
    // Implement client-side filtering or re-fetch from API with search term
  };

  const filteredClients = clients.filter(client => 
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.phone?.includes(searchTerm)
  );

  const handleAddClient = () => {
    // TODO: Implement logic to add a new client (e.g., API call)
    console.log('Adding new client:', currentClient); // currentClient would be the new client data
    // For now, just add to mock data
    const newId = clients.length > 0 ? Math.max(...clients.map(c => c.id)) + 1 : 1;
    setClients([...clients, { ...currentClient, id: newId }]);
    setShowAddModal(false);
    setCurrentClient(null);
  };

  const handleEditClient = () => {
    // TODO: Implement logic to edit an existing client (e.g., API call)
    console.log('Editing client:', currentClient);
    // For now, just update mock data
    setClients(clients.map(c => c.id === currentClient.id ? currentClient : c));
    setShowEditModal(false);
    setCurrentClient(null);
  };

  const handleDeleteClient = (clientId: number) => {
    // TODO: Implement logic to delete a client (e.g., API call)
    console.log('Deleting client ID:', clientId);
    // For now, just filter mock data
    setClients(clients.filter(c => c.id !== clientId));
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-pink-600">Gerenciamento de Clientes</h1>
          <button 
            onClick={() => { setCurrentClient({ name: '', phone: '', email: '', observations: '' }); setShowAddModal(true); }}
            className="bg-pink-600 hover:bg-pink-700 text-white font-semibold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Adicionar Cliente
          </button>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <input 
            type="text" 
            placeholder="Buscar cliente por nome, e-mail ou telefone..."
            value={searchTerm}
            onChange={handleSearch}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
          />
        </div>

        {/* Client List Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-pink-100 text-pink-700">
              <tr>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Nome</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Telefone</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Email</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Última Visita</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Total Gasto</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {filteredClients.map((client) => (
                <tr key={client.id} className="border-b border-gray-200 hover:bg-pink-50 transition-colors duration-150">
                  <td className="py-3 px-4 whitespace-nowrap">{client.name}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{client.phone || '-'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{client.email || '-'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{client.lastVisit || '-'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">R$ {client.totalSpent?.toFixed(2) || '0.00'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <button 
                      onClick={() => { setCurrentClient(client); setShowEditModal(true); }}
                      className="text-blue-500 hover:text-blue-700 mr-2 font-medium"
                    >
                      Editar
                    </button>
                    <button 
                      onClick={() => handleDeleteClient(client.id)}
                      className="text-red-500 hover:text-red-700 font-medium"
                    >
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
              {filteredClients.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-4 px-4 text-center text-gray-500">Nenhum cliente encontrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Add Client Modal (Simplified) */}
        {showAddModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center p-4 z-50">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
              <h3 className="text-2xl font-semibold text-pink-600 mb-6">Adicionar Novo Cliente</h3>
              {/* Form fields for new client - this is a simplified example */}
              <label className="block mb-2">Nome: <input type="text" value={currentClient?.name || ''} onChange={(e) => setCurrentClient({...currentClient, name: e.target.value})} className="w-full p-2 border rounded" /></label>
              <label className="block mb-2">Telefone: <input type="text" value={currentClient?.phone || ''} onChange={(e) => setCurrentClient({...currentClient, phone: e.target.value})} className="w-full p-2 border rounded" /></label>
              <label className="block mb-4">Email: <input type="email" value={currentClient?.email || ''} onChange={(e) => setCurrentClient({...currentClient, email: e.target.value})} className="w-full p-2 border rounded" /></label>
              {/* Add more fields as needed */}
              <div className="flex justify-end space-x-4 mt-6">
                <button onClick={() => setShowAddModal(false)} className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg">Cancelar</button>
                <button onClick={handleAddClient} className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg">Salvar</button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Client Modal (Simplified) */}
        {showEditModal && currentClient && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center p-4 z-50">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
              <h3 className="text-2xl font-semibold text-pink-600 mb-6">Editar Cliente</h3>
              <label className="block mb-2">Nome: <input type="text" value={currentClient.name} onChange={(e) => setCurrentClient({...currentClient, name: e.target.value})} className="w-full p-2 border rounded" /></label>
              <label className="block mb-2">Telefone: <input type="text" value={currentClient.phone || ''} onChange={(e) => setCurrentClient({...currentClient, phone: e.target.value})} className="w-full p-2 border rounded" /></label>
              <label className="block mb-4">Email: <input type="email" value={currentClient.email || ''} onChange={(e) => setCurrentClient({...currentClient, email: e.target.value})} className="w-full p-2 border rounded" /></label>
              {/* Add more fields as needed */}
              <div className="flex justify-end space-x-4 mt-6">
                <button onClick={() => { setShowEditModal(false); setCurrentClient(null); }} className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg">Cancelar</button>
                <button onClick={handleEditClient} className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg">Salvar Alterações</button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default ClientManagementPage;

