import React from 'react';

const SignupPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-200 via-pink-50 to-white p-4">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12 w-full max-w-lg">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-pink-600 tracking-tight">BeautyManager</h1>
          <p className="text-pink-400 mt-2">Crie sua conta e transforme a gestão do seu salão</p>
        </div>
        <form>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="salonName" className="block text-sm font-medium text-pink-700 mb-1">Nome do Salão</label>
              <input 
                type="text" 
                id="salonName" 
                className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300" 
                placeholder="Ex: Salão Beleza Pura"
              />
            </div>
            <div>
              <label htmlFor="ownerName" className="block text-sm font-medium text-pink-700 mb-1">Seu Nome</label>
              <input 
                type="text" 
                id="ownerName" 
                className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300" 
                placeholder="Ex: Maria Silva"
              />
            </div>
          </div>
          <div className="mb-6">
            <label htmlFor="email" className="block text-sm font-medium text-pink-700 mb-1">E-mail</label>
            <input 
              type="email" 
              id="email" 
              className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300" 
              placeholder="seuemail@exemplo.com"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-pink-700 mb-1">Senha</label>
              <input 
                type="password" 
                id="password" 
                className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300" 
                placeholder="Mínimo 8 caracteres"
              />
            </div>
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-pink-700 mb-1">Confirmar Senha</label>
              <input 
                type="password" 
                id="confirmPassword" 
                className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 transition-colors duration-300" 
                placeholder="Repita a senha"
              />
            </div>
          </div>
          <div className="mb-6">
            <label className="flex items-center">
              <input type="checkbox" className="form-checkbox h-5 w-5 text-pink-600 border-pink-300 rounded focus:ring-pink-500" />
              <span className="ml-2 text-sm text-gray-700">Li e aceito os <a href="#" className="font-medium text-pink-600 hover:text-pink-700">Termos de Uso</a> e a <a href="#" className="font-medium text-pink-600 hover:text-pink-700">Política de Privacidade</a>.</span>
            </label>
          </div>
          <button 
            type="submit" 
            className="w-full bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Cadastrar
          </button>
        </form>
        <p className="text-center text-sm text-gray-600 mt-8">
          Já tem uma conta? <a href="#" className="font-medium text-pink-600 hover:text-pink-700 transition-colors duration-300">Faça login</a>
        </p>
      </div>
    </div>
  );
};

export default SignupPage;

