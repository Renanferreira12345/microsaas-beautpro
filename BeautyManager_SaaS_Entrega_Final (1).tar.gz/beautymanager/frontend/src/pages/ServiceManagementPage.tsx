import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockServicesData = [
  { id: 1, name: 'Corte de Cabelo Feminino', price: 70.00, duration: 60, description: 'Corte moderno e estilizado para mulheres.' },
  { id: 2, name: 'Manicure Completa', price: 35.00, duration: 45, description: 'Cutilagem, lixamento e esmaltação.' },
  { id: 3, name: 'Escova Progressiva', price: 250.00, duration: 180, description: 'Alisamento e redução de volume com produtos de alta qualidade.' },
  { id: 4, name: 'Design de Sobrancelhas', price: 40.00, duration: 30, description: 'Modelagem e design de sobrancelhas.' },
];

interface Service {
  id: number;
  name: string;
  price: number;
  duration: number; // in minutes
  description: string;
}

const ServiceManagementPage: React.FC = () => {
  const [services, setServices] = useState<Service[]>(mockServicesData);
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentService, setCurrentService] = useState<Service | null>(null);
  const [newService, setNewService] = useState<Omit<Service, 'id'>>({ name: '', price: 0, duration: 30, description: '' });

  // TODO: Fetch services from API on component mount
  // useEffect(() => {
  //   // fetchServices();
  // }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const val = name === 'price' || name === 'duration' ? parseFloat(value) : value;
    if (isEditing && currentService) {
      setCurrentService({ ...currentService, [name]: val });
    } else {
      setNewService({ ...newService, [name]: val });
    }
  };

  const openAddModal = () => {
    setIsEditing(false);
    setNewService({ name: '', price: 0, duration: 30, description: '' });
    setShowModal(true);
  };

  const openEditModal = (service: Service) => {
    setIsEditing(true);
    setCurrentService(service);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCurrentService(null);
    setIsEditing(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing && currentService) {
      // TODO: API call to update service
      setServices(services.map(s => s.id === currentService.id ? currentService : s));
      console.log('Updating service:', currentService);
    } else {
      // TODO: API call to add new service
      const newId = services.length > 0 ? Math.max(...services.map(s => s.id)) + 1 : 1;
      setServices([...services, { ...newService, id: newId } as Service]);
      console.log('Adding service:', newService);
    }
    closeModal();
  };

  const handleDeleteService = (serviceId: number) => {
    // TODO: API call to delete service
    setServices(services.filter(s => s.id !== serviceId));
    console.log('Deleting service ID:', serviceId);
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-pink-600">Gerenciamento de Serviços</h1>
          <button 
            onClick={openAddModal}
            className="bg-pink-600 hover:bg-pink-700 text-white font-semibold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Adicionar Serviço
          </button>
        </div>

        {/* Service List Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-pink-100 text-pink-700">
              <tr>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Nome</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Preço (R$)</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Duração (min)</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Descrição</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {services.map((service) => (
                <tr key={service.id} className="border-b border-gray-200 hover:bg-pink-50 transition-colors duration-150">
                  <td className="py-3 px-4 whitespace-nowrap">{service.name}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{service.price.toFixed(2)}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{service.duration}</td>
                  <td className="py-3 px-4 whitespace-normal max-w-xs truncate">{service.description}</td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <button 
                      onClick={() => openEditModal(service)}
                      className="text-blue-500 hover:text-blue-700 mr-2 font-medium"
                    >
                      Editar
                    </button>
                    <button 
                      onClick={() => handleDeleteService(service.id)}
                      className="text-red-500 hover:text-red-700 font-medium"
                    >
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
              {services.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 px-4 text-center text-gray-500">Nenhum serviço cadastrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Add/Edit Service Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center p-4 z-50">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
              <h3 className="text-2xl font-semibold text-pink-600 mb-6">{isEditing ? 'Editar Serviço' : 'Adicionar Novo Serviço'}</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-pink-700">Nome do Serviço</label>
                  <input type="text" name="name" id="name" value={isEditing ? currentService?.name : newService.name} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="price" className="block text-sm font-medium text-pink-700">Preço (R$)</label>
                  <input type="number" name="price" id="price" step="0.01" value={isEditing ? currentService?.price : newService.price} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="duration" className="block text-sm font-medium text-pink-700">Duração (minutos)</label>
                  <input type="number" name="duration" id="duration" value={isEditing ? currentService?.duration : newService.duration} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-pink-700">Descrição</label>
                  <textarea name="description" id="description" value={isEditing ? currentService?.description : newService.description} onChange={handleInputChange} rows={3} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500"></textarea>
                </div>
                <div className="flex justify-end space-x-4 pt-4">
                  <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg">Cancelar</button>
                  <button type="submit" className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg">{isEditing ? 'Salvar Alterações' : 'Adicionar Serviço'}</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceManagementPage;

