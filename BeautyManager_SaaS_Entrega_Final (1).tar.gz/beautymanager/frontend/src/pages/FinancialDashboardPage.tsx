import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockMonthlySummary = {
  totalRevenue: 12500.75,
  totalExpenses: 3200.50, // Example, if tracking expenses
  netProfit: 9300.25,
  topClients: [
    { name: 'Cliente A', amount: 1200.00 },
    { name: 'Cliente B', amount: 950.50 },
    { name: 'Cliente C', amount: 800.00 },
  ],
  servicesBreakdown: [
    { service: 'Corte de Cabelo', revenue: 5000.00 },
    { service: 'Manicure', revenue: 2500.75 },
    { service: 'Escova Progressiva', revenue: 4000.00 },
    { service: 'Outros', revenue: 1000.00 },
  ]
};

interface FinancialSummary {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  topClients: { name: string; amount: number }[];
  servicesBreakdown: { service: string; revenue: number }[];
}

const FinancialDashboardPage: React.FC = () => {
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7)); // YYYY-MM format

  // TODO: Fetch financial summary from API based on selectedMonth
  useEffect(() => {
    // Simulating API call
    // In a real app, you'd fetch data for the selectedMonth
    setSummary(mockMonthlySummary);
  }, [selectedMonth]);

  const handleMonthChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedMonth(event.target.value);
    // TODO: Trigger API call to fetch data for the new month
  };

  if (!summary) {
    return <div className="p-6 text-center">Carregando dados financeiros...</div>;
  }

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-pink-600 mb-4 sm:mb-0">Dashboard Financeiro</h1>
          <div>
            <label htmlFor="month-select" className="mr-2 text-pink-700 font-medium">Mês:</label>
            <input 
              type="month" 
              id="month-select"
              value={selectedMonth}
              onChange={handleMonthChange}
              className="border border-pink-300 rounded-lg p-2 focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
            />
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-green-100 p-6 rounded-lg shadow-md text-center">
            <h3 className="text-xl font-semibold text-green-700">Receita Total</h3>
            <p className="text-3xl font-bold text-green-600 mt-2">R$ {summary.totalRevenue.toFixed(2)}</p>
          </div>
          <div className="bg-red-100 p-6 rounded-lg shadow-md text-center">
            <h3 className="text-xl font-semibold text-red-700">Despesas Totais</h3>
            <p className="text-3xl font-bold text-red-600 mt-2">R$ {summary.totalExpenses.toFixed(2)}</p>
          </div>
          <div className="bg-blue-100 p-6 rounded-lg shadow-md text-center">
            <h3 className="text-xl font-semibold text-blue-700">Lucro Líquido</h3>
            <p className="text-3xl font-bold text-blue-600 mt-2">R$ {summary.netProfit.toFixed(2)}</p>
          </div>
        </div>

        {/* Detailed Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Clients */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-pink-600 mb-4">Top Clientes (Mês)</h3>
            <ul className="space-y-2">
              {summary.topClients.map((client, index) => (
                <li key={index} className="flex justify-between p-2 bg-pink-50 rounded">
                  <span>{client.name}</span>
                  <span className="font-semibold">R$ {client.amount.toFixed(2)}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Revenue by Service */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-pink-600 mb-4">Receita por Serviço (Mês)</h3>
            <ul className="space-y-2">
              {summary.servicesBreakdown.map((service, index) => (
                <li key={index} className="flex justify-between p-2 bg-pink-50 rounded">
                  <span>{service.service}</span>
                  <span className="font-semibold">R$ {service.revenue.toFixed(2)}</span>
                </li>
              ))}
            </ul>
            {/* TODO: Consider adding a pie chart here for visual representation */}
          </div>
        </div>

      </div>
    </div>
  );
};

export default FinancialDashboardPage;

