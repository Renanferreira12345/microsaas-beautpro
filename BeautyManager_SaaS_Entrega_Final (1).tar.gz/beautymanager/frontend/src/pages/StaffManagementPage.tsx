import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockStaffData = [
  { id: 1, name: 'Ana Silva', role: 'Cabeleireira', schedule: 'Seg-Sex 9:00-18:00', phone: '11999998877', email: 'ana.silva.staff@example.com' },
  { id: 2, name: 'Carlos Souza', role: 'Manicure/Pedicure', schedule: 'Ter-Sab 10:00-19:00', phone: '21988887766', email: 'carlos.souza.staff@example.com' },
  { id: 3, name: 'Mariana Lima', role: 'Esteticista', schedule: 'Seg-Qua-Sex 8:00-17:00', phone: '31977776655', email: 'mariana.lima.staff@example.com' },
];

interface StaffMember {
  id: number;
  name: string;
  role: string;
  schedule: string;
  phone?: string;
  email?: string;
}

const StaffManagementPage: React.FC = () => {
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>(mockStaffData);
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentStaff, setCurrentStaff] = useState<StaffMember | null>(null);
  const [newStaffMember, setNewStaffMember] = useState<Omit<StaffMember, 'id'>>({ name: '', role: '', schedule: '', phone: '', email: '' });

  // TODO: Fetch staff from API on component mount
  // useEffect(() => {
  //   // fetchStaff();
  // }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (isEditing && currentStaff) {
      setCurrentStaff({ ...currentStaff, [name]: value });
    } else {
      setNewStaffMember({ ...newStaffMember, [name]: value });
    }
  };

  const openAddModal = () => {
    setIsEditing(false);
    setNewStaffMember({ name: '', role: '', schedule: '', phone: '', email: '' });
    setShowModal(true);
  };

  const openEditModal = (staff: StaffMember) => {
    setIsEditing(true);
    setCurrentStaff(staff);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCurrentStaff(null);
    setIsEditing(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing && currentStaff) {
      // TODO: API call to update staff member
      setStaffMembers(staffMembers.map(s => s.id === currentStaff.id ? currentStaff : s));
      console.log('Updating staff member:', currentStaff);
    } else {
      // TODO: API call to add new staff member
      const newId = staffMembers.length > 0 ? Math.max(...staffMembers.map(s => s.id)) + 1 : 1;
      setStaffMembers([...staffMembers, { ...newStaffMember, id: newId } as StaffMember]);
      console.log('Adding staff member:', newStaffMember);
    }
    closeModal();
  };

  const handleDeleteStaff = (staffId: number) => {
    // TODO: API call to delete staff member
    setStaffMembers(staffMembers.filter(s => s.id !== staffId));
    console.log('Deleting staff member ID:', staffId);
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-pink-600">Gerenciamento de Profissionais</h1>
          <button 
            onClick={openAddModal}
            className="bg-pink-600 hover:bg-pink-700 text-white font-semibold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Adicionar Profissional
          </button>
        </div>

        {/* Staff List Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead className="bg-pink-100 text-pink-700">
              <tr>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Nome</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Cargo</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Horário</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Telefone</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Email</th>
                <th className="py-3 px-4 text-left text-sm font-semibold uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              {staffMembers.map((staff) => (
                <tr key={staff.id} className="border-b border-gray-200 hover:bg-pink-50 transition-colors duration-150">
                  <td className="py-3 px-4 whitespace-nowrap">{staff.name}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{staff.role}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{staff.schedule}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{staff.phone || '-'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">{staff.email || '-'}</td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <button 
                      onClick={() => openEditModal(staff)}
                      className="text-blue-500 hover:text-blue-700 mr-2 font-medium"
                    >
                      Editar
                    </button>
                    <button 
                      onClick={() => handleDeleteStaff(staff.id)}
                      className="text-red-500 hover:text-red-700 font-medium"
                    >
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
              {staffMembers.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-4 px-4 text-center text-gray-500">Nenhum profissional cadastrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Add/Edit Staff Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center p-4 z-50">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
              <h3 className="text-2xl font-semibold text-pink-600 mb-6">{isEditing ? 'Editar Profissional' : 'Adicionar Novo Profissional'}</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-pink-700">Nome</label>
                  <input type="text" name="name" id="name" value={isEditing ? currentStaff?.name : newStaffMember.name} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="role" className="block text-sm font-medium text-pink-700">Cargo</label>
                  <input type="text" name="role" id="role" value={isEditing ? currentStaff?.role : newStaffMember.role} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="schedule" className="block text-sm font-medium text-pink-700">Horário de Trabalho</label>
                  <input type="text" name="schedule" id="schedule" value={isEditing ? currentStaff?.schedule : newStaffMember.schedule} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" required />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-pink-700">Telefone</label>
                  <input type="tel" name="phone" id="phone" value={isEditing ? currentStaff?.phone : newStaffMember.phone} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-pink-700">Email</label>
                  <input type="email" name="email" id="email" value={isEditing ? currentStaff?.email : newStaffMember.email} onChange={handleInputChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md focus:ring-pink-500 focus:border-pink-500" />
                </div>
                <div className="flex justify-end space-x-4 pt-4">
                  <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg">Cancelar</button>
                  <button type="submit" className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg">{isEditing ? 'Salvar Alterações' : 'Adicionar Profissional'}</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StaffManagementPage;

