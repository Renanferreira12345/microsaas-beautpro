import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockAppointmentHistory = [
  { id: 1, clientId: 101, serviceName: 'Corte de Cabelo', professionalName: 'Ana Silva', date: '2024-04-10', time: '10:00', status: 'Concluído', notes: 'Cliente satisfeita com o corte.' },
  { id: 2, clientId: 101, serviceName: 'Manicure', professionalName: 'Carlos Souza', date: '2024-03-15', time: '14:00', status: 'Concluído', notes: 'Unhas bem feitas.' },
  { id: 3, clientId: 102, serviceName: 'Escova Progressiva', professionalName: 'Ana Silva', date: '2024-02-20', time: '11:30', status: 'Cancelado', notes: 'Cliente desmarcou.' },
];

interface AppointmentHistoryEntry {
  id: number;
  clientId: number; // To link history to a specific client
  serviceName: string;
  professionalName: string;
  date: string;
  time: string;
  status: 'Concluído' | 'Cancelado' | 'Agendado'; // Example statuses
  notes?: string;
}

// Props would typically include clientId to fetch history for a specific client
interface AppointmentHistoryPageProps {
  clientId: number; // Example: passed as a prop or from route params
}

const AppointmentHistoryPage: React.FC<AppointmentHistoryPageProps> = ({ clientId }) => {
  const [appointmentHistory, setAppointmentHistory] = useState<AppointmentHistoryEntry[]>([]);

  // TODO: Fetch appointment history from API based on clientId
  useEffect(() => {
    // Simulating API call
    const clientSpecificHistory = mockAppointmentHistory.filter(app => app.clientId === clientId);
    setAppointmentHistory(clientSpecificHistory);
  }, [clientId]);

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <h1 className="text-3xl font-bold text-pink-600 mb-8 text-center">Histórico de Atendimentos (Cliente ID: {clientId})</h1>
        
        {appointmentHistory.length > 0 ? (
          <div className="space-y-6">
            {appointmentHistory.map(appointment => (
              <div key={appointment.id} className="p-4 border border-gray-200 rounded-lg shadow-sm bg-white hover:shadow-md transition-shadow">
                <h3 className="text-xl font-semibold text-pink-700">{appointment.serviceName}</h3>
                <p className="text-sm text-gray-600">Profissional: {appointment.professionalName}</p>
                <p className="text-sm text-gray-600">Data: {new Date(appointment.date + 'T' + appointment.time).toLocaleDateString()} às {appointment.time}</p>
                <p className="text-sm text-gray-600">Status: <span className={`font-medium ${appointment.status === 'Concluído' ? 'text-green-600' : appointment.status === 'Cancelado' ? 'text-red-600' : 'text-yellow-600'}`}>{appointment.status}</span></p>
                {appointment.notes && <p className="text-sm text-gray-500 mt-1">Observações: {appointment.notes}</p>}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">Nenhum histórico de atendimento encontrado para este cliente.</p>
        )}
      </div>
    </div>
  );
};

export default AppointmentHistoryPage;

