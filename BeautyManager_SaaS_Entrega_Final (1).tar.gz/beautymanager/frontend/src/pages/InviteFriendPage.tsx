import React, { useState } from 'react';

const InviteFriendPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(event.target.value);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    setIsSent(false);

    if (!email) {
      setError('Por favor, insira o e-mail do seu amigo.');
      return;
    }

    // TODO: Implement actual email sending logic (e.g., via an API endpoint)
    // For this example, we'll simulate it with a timeout
    console.log(`Sending invitation to: ${email}`);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000)); 
      // Assume API call is successful
      setIsSent(true);
      setEmail(''); // Clear the input field
    } catch (err) {
      setError('Ocorreu um erro ao enviar o convite. Tente novamente mais tarde.');
      console.error('Error sending invitation:', err);
    }
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6 flex items-center justify-center">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12 max-w-lg w-full">
        <h1 className="text-3xl font-bold text-pink-600 mb-6 text-center">Convide um Amigo</h1>
        <p className="text-center text-gray-600 mb-8">
          Convide um amigo para usar o BeautyManager e ambos ganham 1 mês grátis no plano Premium quando ele assinar!
        </p>

        {isSent && (
          <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-md">
            Convite enviado com sucesso! Seu amigo receberá um e-mail em breve.
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="friendEmail" className="block text-sm font-medium text-pink-700 mb-1">
              E-mail do Amigo
            </label>
            <input 
              type="email" 
              id="friendEmail" 
              name="friendEmail"
              value={email}
              onChange={handleEmailChange}
              className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
              placeholder="amigo@exemplo.com"
              required 
            />
          </div>

          <button 
            type="submit" 
            className="w-full bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Enviar Convite
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-xs text-gray-500">
            *Termos e condições se aplicam. O mês grátis será creditado após a confirmação da assinatura do seu amigo no plano Premium.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InviteFriendPage;

