import React from 'react';
import { Link } from 'react-router-dom'; // Assuming you're using React Router for navigation

const DashboardPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-pink-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-md p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-pink-600">BeautyManager</h1>
        <div className="flex items-center space-x-4">
          <Link to="/notifications" className="text-pink-500 hover:text-pink-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </Link>
          <Link to="/profile" className="text-pink-500 hover:text-pink-700">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </Link>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow p-6">
        <h2 className="text-3xl font-semibold text-gray-700 mb-6">Painel de Controle</h2>
        
        {/* Placeholder for Dashboard Widgets/Components */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Example Widget 1 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold text-pink-600 mb-2">Agendamentos de Hoje</h3>
            <p className="text-gray-600">Você tem X agendamentos hoje.</p>
            <Link to="/appointments" className="text-pink-500 hover:text-pink-700 font-medium mt-4 inline-block">Ver Agendamentos</Link>
          </div>

          {/* Example Widget 2 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold text-pink-600 mb-2">Clientes Recentes</h3>
            <p className="text-gray-600">X novos clientes este mês.</p>
            <Link to="/clients" className="text-pink-500 hover:text-pink-700 font-medium mt-4 inline-block">Gerenciar Clientes</Link>
          </div>

          {/* Example Widget 3 */}
          <div className="bg-white p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold text-pink-600 mb-2">Faturamento do Mês</h3>
            <p className="text-gray-600">R$ YYYY,ZZ faturados até agora.</p>
            <Link to="/billing" className="text-pink-500 hover:text-pink-700 font-medium mt-4 inline-block">Ver Relatórios</Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-pink-700 text-white p-4 text-center">
        © 2024 BeautyManager. Todos os direitos reservados.
      </footer>
    </div>
  );
};

export default DashboardPage;

