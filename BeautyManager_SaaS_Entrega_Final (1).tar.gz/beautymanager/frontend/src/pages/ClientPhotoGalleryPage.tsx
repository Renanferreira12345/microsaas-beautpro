import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls and proper state management
const mockClientPhotos = [
  { id: 1, clientId: 101, photoUrl: 'https://via.placeholder.com/300x200.png?text=Antes+1', type: 'before', description: 'Cabelo antes do tratamento X', uploadDate: '2024-01-10' },
  { id: 2, clientId: 101, photoUrl: 'https://via.placeholder.com/300x200.png?text=Depois+1', type: 'after', description: 'Cabelo depois do tratamento X', uploadDate: '2024-01-12' },
  { id: 3, clientId: 102, photoUrl: 'https://via.placeholder.com/300x200.png?text=Antes+2', type: 'before', description: 'Pele antes do procedimento Y', uploadDate: '2024-02-05' },
  { id: 4, clientId: 102, photoUrl: 'https://via.placeholder.com/300x200.png?text=Depois+2', type: 'after', description: 'Pele depois do procedimento Y', uploadDate: '2024-02-06' },
];

interface ClientPhoto {
  id: number;
  clientId: number; // To link photos to a specific client
  photoUrl: string;
  type: 'before' | 'after';
  description?: string;
  uploadDate: string;
}

// Props would typically include clientId to fetch photos for a specific client
interface ClientPhotoGalleryPageProps {
  clientId: number; // Example: passed as a prop or from route params
}

const ClientPhotoGalleryPage: React.FC<ClientPhotoGalleryPageProps> = ({ clientId }) => {
  const [photos, setPhotos] = useState<ClientPhoto[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [newPhoto, setNewPhoto] = useState<{ file: File | null, type: 'before' | 'after', description: string }>({ file: null, type: 'before', description: '' });

  // TODO: Fetch client photos from API based on clientId
  useEffect(() => {
    // Simulating API call
    const clientSpecificPhotos = mockClientPhotos.filter(p => p.clientId === clientId);
    setPhotos(clientSpecificPhotos);
  }, [clientId]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setNewPhoto({ ...newPhoto, file: event.target.files[0] });
    }
  };

  const handleUpload = (event: React.FormEvent) => {
    event.preventDefault();
    if (!newPhoto.file) {
      alert('Por favor, selecione uma imagem.');
      return;
    }
    // TODO: Implement actual file upload to server (e.g., S3, Firebase Storage) and then update database
    const newPhotoEntry: ClientPhoto = {
      id: Math.max(0, ...photos.map(p => p.id)) + 1, // Mock ID generation
      clientId: clientId,
      photoUrl: URL.createObjectURL(newPhoto.file), // Temporary URL for display, real URL from server
      type: newPhoto.type,
      description: newPhoto.description,
      uploadDate: new Date().toISOString().split('T')[0],
    };
    setPhotos([...photos, newPhotoEntry]);
    console.log('Uploading photo:', newPhoto.file?.name, 'Type:', newPhoto.type, 'Description:', newPhoto.description);
    setShowUploadModal(false);
    setNewPhoto({ file: null, type: 'before', description: '' });
  };

  const handleDeletePhoto = (photoId: number) => {
    // TODO: API call to delete photo from server and database
    setPhotos(photos.filter(p => p.id !== photoId));
    console.log('Deleting photo ID:', photoId);
  };

  return (
    <div className="min-h-screen bg-pink-50 p-6">
      <div className="bg-white shadow-2xl rounded-xl p-8 md:p-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-pink-600">Galeria de Fotos do Cliente (ID: {clientId})</h1>
          <button 
            onClick={() => setShowUploadModal(true)}
            className="bg-pink-600 hover:bg-pink-700 text-white font-semibold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
          >
            Adicionar Foto
          </button>
        </div>

        {/* Photo Grid */}
        {photos.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {photos.map(photo => (
              <div key={photo.id} className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden">
                <img src={photo.photoUrl} alt={photo.description || `Foto ${photo.id}`} className="w-full h-48 object-cover" />
                <div className="p-4">
                  <p className="text-sm text-gray-600">Tipo: {photo.type === 'before' ? 'Antes' : 'Depois'}</p>
                  <p className="text-sm text-gray-600">Data: {new Date(photo.uploadDate).toLocaleDateString()}</p>
                  {photo.description && <p className="text-sm text-gray-500 mt-1 truncate">{photo.description}</p>}
                  <button 
                    onClick={() => handleDeletePhoto(photo.id)}
                    className="mt-2 text-xs text-red-500 hover:text-red-700 font-medium"
                  >
                    Excluir
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">Nenhuma foto encontrada para este cliente.</p>
        )}

        {/* Upload Photo Modal */}
        {showUploadModal && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75 overflow-y-auto h-full w-full flex items-center justify-center p-4 z-50">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
              <h3 className="text-2xl font-semibold text-pink-600 mb-6">Adicionar Nova Foto</h3>
              <form onSubmit={handleUpload} className="space-y-4">
                <div>
                  <label htmlFor="photoFile" className="block text-sm font-medium text-pink-700">Arquivo da Foto</label>
                  <input type="file" id="photoFile" accept="image/*" onChange={handleFileChange} className="mt-1 w-full p-2 border border-pink-300 rounded-md" required />
                </div>
                <div>
                  <label htmlFor="photoType" className="block text-sm font-medium text-pink-700">Tipo</label>
                  <select id="photoType" value={newPhoto.type} onChange={(e) => setNewPhoto({...newPhoto, type: e.target.value as 'before' | 'after'})} className="mt-1 w-full p-2 border border-pink-300 rounded-md">
                    <option value="before">Antes</option>
                    <option value="after">Depois</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="photoDescription" className="block text-sm font-medium text-pink-700">Descrição (opcional)</label>
                  <textarea id="photoDescription" value={newPhoto.description} onChange={(e) => setNewPhoto({...newPhoto, description: e.target.value})} rows={3} className="mt-1 w-full p-2 border border-pink-300 rounded-md"></textarea>
                </div>
                <div className="flex justify-end space-x-4 pt-4">
                  <button type="button" onClick={() => { setShowUploadModal(false); setNewPhoto({ file: null, type: 'before', description: '' }); }} className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg">Cancelar</button>
                  <button type="submit" className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg">Enviar Foto</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientPhotoGalleryPage;

