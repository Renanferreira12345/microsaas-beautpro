import React, { useState } from 'react';

const ShareAgendaComponent: React.FC = () => {
  const [shareLink, setShareLink] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateShareLink = () => {
    setIsLoading(true);
    // Simulate API call to generate a unique shareable link
    setTimeout(() => {
      const uniqueId = Math.random().toString(36).substring(2, 15);
      const generatedLink = `${window.location.origin}/shared-agenda/${uniqueId}`;
      setShareLink(generatedLink);
      setIsLoading(false);
    }, 1000);
  };

  const copyToClipboard = () => {
    if (shareLink) {
      navigator.clipboard.writeText(shareLink)
        .then(() => alert('Link copiado para a área de transferência!'))
        .catch(err => console.error('Erro ao copiar link: ', err));
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg max-w-md mx-auto my-8">
      <h2 className="text-2xl font-semibold text-pink-600 mb-6 text-center">Compartilhar Agenda</h2>
      {!shareLink && (
        <button 
          onClick={generateShareLink}
          disabled={isLoading}
          className="w-full bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105 disabled:opacity-50"
        >
          {isLoading ? 'Gerando link...' : 'Gerar Link de Compartilhamento'}
        </button>
      )}
      {shareLink && (
        <div className="mt-4">
          <p className="text-sm text-gray-600 mb-2">Compartilhe este link com seus clientes:</p>
          <div className="flex items-center border border-pink-300 rounded-lg p-2">
            <input 
              type="text" 
              value={shareLink} 
              readOnly 
              className="w-full text-pink-700 bg-transparent focus:outline-none"
            />
            <button 
              onClick={copyToClipboard}
              className="ml-2 bg-pink-100 hover:bg-pink-200 text-pink-700 font-semibold py-2 px-3 rounded-lg text-sm"
            >
              Copiar
            </button>
          </div>
          <button 
            onClick={() => setShareLink(null)} 
            className="mt-4 text-sm text-pink-600 hover:underline"
          >
            Gerar novo link
          </button>
        </div>
      )}
      <p className="text-xs text-gray-500 mt-6 text-center">
        Nota: Este link permitirá que seus clientes visualizem sua disponibilidade (conforme configurado por você) e solicitem agendamentos.
      </p>
    </div>
  );
};

export default ShareAgendaComponent;

