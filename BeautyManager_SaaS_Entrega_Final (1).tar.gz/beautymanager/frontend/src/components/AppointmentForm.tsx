import React, { useState, useEffect } from 'react';

// Mock data - replace with API calls
const mockServices = [
  { id: 1, name: 'Corte de Cabelo', price: 50, duration: 60 },
  { id: 2, name: 'Manicure', price: 30, duration: 45 },
  { id: 3, name: 'Escova Progressiva', price: 150, duration: 120 },
];

const mockProfessionals = [
  { id: 1, name: 'Ana Silva' },
  { id: 2, name: 'Carlos Souza' },
  { id: 3, name: 'Mariana Lima' },
];

const AppointmentForm: React.FC = () => {
  const [selectedService, setSelectedService] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedProfessional, setSelectedProfessional] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('pix'); // 'pix' or 'card'

  // TODO: Fetch services and professionals from API
  // useEffect(() => {
  //   // Fetch services and professionals
  // }, []);

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    // TODO: Handle form submission, e.g., send data to API
    console.log({
      service: selectedService,
      date: selectedDate,
      time: selectedTime,
      professional: selectedProfessional,
      paymentMethod,
    });
    alert('Agendamento solicitado! (Simulação)');
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg max-w-lg mx-auto my-8">
      <h2 className="text-2xl font-semibold text-pink-600 mb-6 text-center">Novo Agendamento</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="service" className="block text-sm font-medium text-pink-700 mb-1">Serviço</label>
          <select 
            id="service" 
            value={selectedService}
            onChange={(e) => setSelectedService(e.target.value)}
            className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
            required
          >
            <option value="" disabled>Selecione um serviço</option>
            {mockServices.map(service => (
              <option key={service.id} value={service.id}>{service.name} - R${service.price.toFixed(2)}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="professional" className="block text-sm font-medium text-pink-700 mb-1">Profissional</label>
          <select 
            id="professional" 
            value={selectedProfessional}
            onChange={(e) => setSelectedProfessional(e.target.value)}
            className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
            required
          >
            <option value="" disabled>Selecione um profissional</option>
            {mockProfessionals.map(prof => (
              <option key={prof.id} value={prof.id}>{prof.name}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-pink-700 mb-1">Data</label>
            <input 
              type="date" 
              id="date" 
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
              required 
            />
          </div>
          <div>
            <label htmlFor="time" className="block text-sm font-medium text-pink-700 mb-1">Horário</label>
            <input 
              type="time" 
              id="time" 
              value={selectedTime}
              onChange={(e) => setSelectedTime(e.target.value)}
              className="w-full px-4 py-3 border border-pink-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500"
              required 
            />
          </div>
        </div>

        <div>
          <span className="block text-sm font-medium text-pink-700 mb-1">Forma de Pagamento</span>
          <div className="mt-2 flex flex-col sm:flex-row sm:space-x-4 space-y-2 sm:space-y-0">
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                className="form-radio h-5 w-5 text-pink-600" 
                name="paymentMethod" 
                value="pix" 
                checked={paymentMethod === 'pix'}
                onChange={() => setPaymentMethod('pix')} 
              />
              <span className="ml-2 text-gray-700">PIX</span>
            </label>
            <label className="inline-flex items-center">
              <input 
                type="radio" 
                className="form-radio h-5 w-5 text-pink-600" 
                name="paymentMethod" 
                value="card" 
                checked={paymentMethod === 'card'}
                onChange={() => setPaymentMethod('card')} 
              />
              <span className="ml-2 text-gray-700">Cartão de Crédito/Débito</span>
            </label>
          </div>
        </div>

        <button 
          type="submit" 
          className="w-full bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition-transform duration-150 ease-in-out transform hover:scale-105"
        >
          Agendar Horário
        </button>
      </form>
    </div>
  );
};

export default AppointmentForm;

