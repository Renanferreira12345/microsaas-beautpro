import React, { useState } from 'react';
import Calendar from 'react-calendar'; // Assuming react-calendar is installed
import 'react-calendar/dist/Calendar.css'; // Default styling for react-calendar

// Mock data for appointments - replace with API call
const mockAppointments = [
  {
    date: new Date(2024, 4, 10, 10, 0), // Note: Month is 0-indexed (0 for January)
    professional: 'Ana Silva',
    service: 'Corte de Cabelo',
  },
  {
    date: new Date(2024, 4, 10, 14, 0),
    professional: 'Carlos Souza',
    service: 'Manicure',
  },
  {
    date: new Date(2024, 4, 12, 11, 30),
    professional: 'Ana Silva',
    service: 'Escova Progressiva',
  },
];

type ValuePiece = Date | null;

type Value = ValuePiece | [ValuePiece, ValuePiece];

const InteractiveCalendar: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<Value>(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month'); // Example view state

  // Function to render appointments on the calendar
  const tileContent = ({ date, view }: { date: Date; view: string }) => {
    if (view === 'month') {
      const dayAppointments = mockAppointments.filter(
        (app) =>
          app.date.getFullYear() === date.getFullYear() &&
          app.date.getMonth() === date.getMonth() &&
          app.date.getDate() === date.getDate()
      );
      if (dayAppointments.length > 0) {
        return (
          <ul className="text-xs mt-1">
            {dayAppointments.map((app, index) => (
              <li key={index} className="text-pink-500 truncate">
                {app.professional.split(' ')[0]}: {app.service}
              </li>
            ))}
          </ul>
        );
      }
    }
    return null;
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-semibold text-pink-600 mb-4">Calendário de Agendamentos</h2>
      <div className="mb-4 flex space-x-2">
        <button onClick={() => setView('month')} className={`px-3 py-1 rounded-md text-sm font-medium ${view === 'month' ? 'bg-pink-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>Mês</button>
        {/* Add week and day views if needed */}
      </div>
      <Calendar
        onChange={setSelectedDate}
        value={selectedDate}
        tileContent={tileContent}
        className="react-calendar-custom"
      />
      {/* Display selected date or appointments for the selected date below if needed */}
    </div>
  );
};

export default InteractiveCalendar;

