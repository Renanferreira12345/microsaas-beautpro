import React from 'react';
import './App.css'; // For any global styles not covered by Tailwind utility classes
// import RouterComponent from './routes'; // Assuming a router setup later

function App() {
  return (
    <div className="min-h-screen bg-pink-50 text-gray-800">
      {/* <RouterComponent /> */}
      <h1 className="text-3xl font-bold text-center text-pink-700 p-8">
        BeautyManager - Frontend em Construção
      </h1>
      <p className="text-center">
        Bem-vindo ao painel do BeautyManager. As interfaces estão sendo desenvolvidas!
      </p>
      {/* Placeholder for Login/Signup Page or Dashboard once routing is set up */}
    </div>
  );
}

export default App;

