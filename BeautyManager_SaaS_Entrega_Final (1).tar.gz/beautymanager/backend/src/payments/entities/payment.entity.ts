import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { SubscriptionPlan } from '../../subscription-plans/entities/subscription-plan.entity';

@Entity('payments')
export class Payment {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.payments, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @ManyToOne(() => SubscriptionPlan, plan => plan.users, { nullable: true, onDelete: 'SET NULL', onUpdate: 'CASCADE' })
  subscription_plan: SubscriptionPlan;

  @Column({ type: 'varchar', length: 255, unique: true, nullable: true })
  stripe_charge_id: string;

  @Column({ type: 'varchar', length: 255, unique: true, nullable: true })
  stripe_invoice_id: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  stripe_subscription_id: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount_paid: number;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  @Column({ type: 'varchar', length: 50 })
  status: string; // e.g., 'succeeded', 'pending', 'failed'

  @Column({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' })
  payment_date: Date;

  @Column({ type: 'timestamptz', nullable: true })
  billing_period_start: Date;

  @Column({ type: 'timestamptz', nullable: true })
  billing_period_end: Date;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

