import { Controller, Post, Body, ValidationPipe, HttpCode, HttpStatus, UseGuards, Req, Get } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthCredentialsDto } from './dto/auth-credentials.dto'; // Create this DTO
import { CreateUserDto } from '../users/dto/create-user.dto'; // Create this DTO
import { JwtAuthGuard } from './guards/jwt-auth.guard'; // Create this Guard
import { User } from '../users/entities/user.entity';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('/signup')
  async signUp(@Body(ValidationPipe) createUserDto: CreateUserDto): Promise<{ message: string }> {
    await this.authService.signUp(createUserDto);
    return { message: 'User successfully registered. Please login.' };
  }

  @Post('/signin')
  @HttpCode(HttpStatus.OK)
  async signIn(@Body(ValidationPipe) authCredentialsDto: AuthCredentialsDto): Promise<{ accessToken: string }> {
    return this.authService.signIn(authCredentialsDto);
  }

  @UseGuards(JwtAuthGuard)
  @Get('/me')
  getMe(@Req() req): User {
    // req.user is populated by JwtAuthGuard (JwtStrategy)
    // We should return only necessary user fields, not the whole entity with password hash
    const { password_hash, ...result } = req.user;
    return result as User; // Cast to User, excluding password_hash
  }
}

