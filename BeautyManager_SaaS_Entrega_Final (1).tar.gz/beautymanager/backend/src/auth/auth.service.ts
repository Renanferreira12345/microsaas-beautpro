import { Injectable, UnauthorizedException, ConflictException, InternalServerErrorException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { UsersService } from "../users/users.service";
import { CreateUserDto } from "../users/dto/create-user.dto";
import { AuthCredentialsDto } from "./dto/auth-credentials.dto";
import * as bcrypt from "bcryptjs";
import { User } from "../users/entities/user.entity";

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
  ) {}

  async signUp(createUserDto: CreateUserDto): Promise<User> {
    // The createUser method in UsersService already handles hashing and saving.
    // It also throws ConflictException if email is in use.
    // We might want to remove password_hash from CreateUserDto and handle it here or ensure UsersService does.
    // For now, assuming UsersService.createUser expects a DTO that might include a plain password to be hashed.
    // Let's adjust UsersService.createUser to accept plain password and hash it.

    // Modify createUserDto to match what UsersService.createUser expects if it's different
    // For instance, if UsersService.createUser expects 'password' instead of 'password_hash'
    const { password, ...restOfDto } = createUserDto;

    // The UsersService.createUser should handle password hashing internally.
    // Let's assume it's modified to do so.
    try {
      const user = await this.usersService.createUser({
        ...restOfDto,
        password_hash: password, // Pass the plain password to be hashed by UsersService
      });
      // Exclude password_hash from the returned user object
      const { password_hash, ...result } = user;
      return result as User;
    } catch (error) {
      if (error instanceof ConflictException || error instanceof InternalServerErrorException) {
        throw error;
      }
      throw new InternalServerErrorException("An unexpected error occurred during sign up.");
    }
  }

  async signIn(authCredentialsDto: AuthCredentialsDto): Promise<{ accessToken: string }> {
    const { email, password } = authCredentialsDto;
    const user = await this.usersService.findOneByEmail(email);

    if (user && (await bcrypt.compare(password, user.password_hash))) {
      const payload = { email: user.email, sub: user.id, id: user.id }; // Add id to payload for JwtStrategy
      const accessToken = this.jwtService.sign(payload);
      return { accessToken };
    } else {
      throw new UnauthorizedException("Invalid credentials");
    }
  }

  async validateUserById(id: number): Promise<User | null> {
    return this.usersService.findOneById(id);
  }
}

