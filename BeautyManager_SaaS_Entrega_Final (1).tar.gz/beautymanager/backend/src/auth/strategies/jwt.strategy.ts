import { Injectable, UnauthorizedException } from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { UsersService } from "../../users/users.service"; // Adjust path as needed
import { User } from "../../users/entities/user.entity"; // Adjust path as needed

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly usersService: UsersService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || "yourSecretKey", // Ensure this matches the secret in AuthModule
    });
  }

  async validate(payload: { id: number; email: string }): Promise<User> {
    const user = await this.usersService.findOneById(payload.id);
    if (!user) {
      throw new UnauthorizedException();
    }
    // You might want to return a subset of user info, excluding sensitive data like password_hash
    // For now, returning the full user entity (password_hash should be handled by the controller or service returning the user)
    return user;
  }
}

