import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { UsersModule } from '../users/users.module'; // Import UsersModule
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from './strategies/jwt.strategy';
import { AuthController } from './auth.controller'; // Assuming you'll create this
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../users/entities/user.entity';

@Module({
  imports: [
    UsersModule, // Import UsersModule to use UsersService
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      secret: process.env.JWT_SECRET || 'yourSecretKey', // Use environment variable for secret
      signOptions: { expiresIn: '1d' }, // Token expiration time
    }),
    TypeOrmModule.forFeature([User]), // If AuthService needs to interact with User entity directly
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController], // Add AuthController
  exports: [PassportModule, JwtModule, AuthService], // Export AuthService if needed elsewhere
})
export class AuthModule {}

