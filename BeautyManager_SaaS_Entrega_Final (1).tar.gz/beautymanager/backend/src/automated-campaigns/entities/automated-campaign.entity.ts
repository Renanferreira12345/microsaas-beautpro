import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Notification } from '../../notifications/entities/notification.entity';

@Entity('automated_campaigns')
export class AutomatedCampaign {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.automated_campaigns, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @Column({ type: 'varchar', length: 255 })
  name: string; // e.g., 'Lembrete Pós-Atendimento 30 dias'

  @Column({ type: 'varchar', length: 100 })
  trigger_event: string; // e.g., 'appointment_completed', 'client_inactive_days'

  @Column({ type: 'integer', nullable: true })
  trigger_condition_days: number; // e.g., 30 for 'client_inactive_days'

  @Column({ type: 'varchar', length: 255, nullable: true })
  message_template_email_subject: string;

  @Column({ type: 'text', nullable: true })
  message_template_email_body: string; // Can use placeholders like {{client_name}}

  @Column({ type: 'text', nullable: true })
  message_template_whatsapp: string;

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships
  @OneToMany(() => Notification, notification => notification.campaign)
  notifications: Notification[];
}

