import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
import { Appointment } from '../../appointments/entities/appointment.entity';
import { AutomatedCampaign } from '../../automated-campaigns/entities/automated-campaign.entity';

@Entity('notifications')
export class Notification {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.notifications, { onDelete: 'CASCADE', onUpdate: 'CASCADE', nullable: true })
  user: User; // Salon user, if the notification is general for the salon

  @ManyToOne(() => Client, client => client.notifications, { onDelete: 'CASCADE', onUpdate: 'CASCADE', nullable: true })
  client: Client; // Client of the salon, if the notification is specific to a client

  @ManyToOne(() => Appointment, appointment => appointment.notifications, { onDelete: 'SET NULL', onUpdate: 'CASCADE', nullable: true })
  appointment: Appointment; // Appointment related to the notification

  @ManyToOne(() => AutomatedCampaign, campaign => campaign.notifications, { onDelete: 'SET NULL', onUpdate: 'CASCADE', nullable: true })
  campaign: AutomatedCampaign; // Campaign that triggered the notification

  @Column({ type: 'varchar', length: 50 })
  type: string; // e.g., 'email_reminder', 'whatsapp_reminder', 'email_campaign'

  @Column({ type: 'varchar', length: 255 })
  recipient_address: string; // Email address or WhatsApp number

  @Column({ type: 'varchar', length: 255, nullable: true })
  subject: string; // For email notifications

  @Column({ type: 'text' })
  content: string; // Message content

  @Column({ type: 'varchar', length: 50, default: 'pending' })
  status: string; // e.g., 'pending', 'sent', 'failed', 'delivered', 'read'

  @Column({ type: 'timestamptz', nullable: true })
  sent_at: Date;

  @Column({ type: 'text', nullable: true })
  error_message: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

