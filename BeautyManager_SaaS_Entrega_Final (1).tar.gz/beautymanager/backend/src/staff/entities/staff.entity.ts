import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Appointment } from '../../appointments/entities/appointment.entity';

@Entity('staff')
export class Staff {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.staff_members, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  email: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  phone: string;

  @Column({ type: 'text', nullable: true })
  specialties: string; // Could be JSONB for a list: ["corte", "coloração"]

  @Column({ type: 'jsonb', nullable: true })
  work_schedule: any; // e.g., {"monday": {"start": "09:00", "end": "18:00"}, ...}

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships
  @OneToMany(() => Appointment, appointment => appointment.staff)
  appointments: Appointment[];
}

