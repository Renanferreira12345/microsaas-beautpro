import { Injectable, NotFoundException, ForbiddenException, InternalServerErrorException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Client } from "./entities/client.entity";
import { CreateClientDto } from "./dto/create-client.dto";
import { UpdateClientDto } from "./dto/update-client.dto";
import { User } from "../users/entities/user.entity"; // To associate client with a salon user

@Injectable()
export class ClientsService {
  constructor(
    @InjectRepository(Client)
    private readonly clientsRepository: Repository<Client>,
  ) {}

  async create(createClientDto: CreateClientDto, salonUser: User): Promise<Client> {
    const newClient = this.clientsRepository.create({
      ...createClientDto,
      user: salonUser, // Associate with the currently authenticated salon user
    });
    try {
      return await this.clientsRepository.save(newClient);
    } catch (error) {
        // Log the error for debugging
        console.error("Error creating client:", error);
        throw new InternalServerErrorException("Could not create client.");
    }
  }

  async findAllBySalon(salonUser: User): Promise<Client[]> {
    return this.clientsRepository.find({ where: { user: { id: salonUser.id } } });
  }

  async findOneByIdAndSalon(id: number, salonUser: User): Promise<Client> {
    const client = await this.clientsRepository.findOne({ where: { id, user: { id: salonUser.id } } });
    if (!client) {
      throw new NotFoundException(`Client with ID "${id}" not found or does not belong to your salon.`);
    }
    return client;
  }

  async update(id: number, updateClientDto: UpdateClientDto, salonUser: User): Promise<Client> {
    const client = await this.findOneByIdAndSalon(id, salonUser); // Ensures client exists and belongs to user
    
    // Merge existing client with update DTO
    this.clientsRepository.merge(client, updateClientDto);

    try {
        return await this.clientsRepository.save(client);
    } catch (error) {
        console.error("Error updating client:", error);
        throw new InternalServerErrorException("Could not update client.");
    }
  }

  async remove(id: number, salonUser: User): Promise<{ message: string }> {
    const client = await this.findOneByIdAndSalon(id, salonUser); // Ensures client exists and belongs to user
    const result = await this.clientsRepository.delete(client.id);
    if (result.affected === 0) {
      // This case should ideally be caught by findOneByIdAndSalon if client doesn't exist
      throw new NotFoundException(`Client with ID "${id}" not found.`);
    }
    return { message: `Client with ID "${id}" successfully deleted.` };
  }

  // Admin specific methods (if an admin needs to manage all clients across all salons)
  async findAllAsAdmin(): Promise<Client[]> {
    // This method should be protected by an admin role guard
    return this.clientsRepository.find({ relations: ["user"] }); // Include salon user info
  }

  async findOneByIdAsAdmin(id: number): Promise<Client> {
    // This method should be protected by an admin role guard
    const client = await this.clientsRepository.findOne({ where: { id }, relations: ["user"] });
    if (!client) {
      throw new NotFoundException(`Client with ID "${id}" not found.`);
    }
    return client;
  }
}

