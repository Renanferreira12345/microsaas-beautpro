import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Appointment } from '../../appointments/entities/appointment.entity';
import { Photo } from '../../photos/entities/photo.entity';
import { Notification } from '../../notifications/entities/notification.entity';

@Entity('clients')
export class Client {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.clients, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @Column({ type: 'varchar', length: 255 })
  name: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  phone: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  email: string;

  @Column({ type: 'date', nullable: true })
  date_of_birth: Date;

  @Column({ type: 'text', nullable: true })
  address: string;

  @Column({ type: 'text', nullable: true })
  observations: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships
  @OneToMany(() => Appointment, appointment => appointment.client)
  appointments: Appointment[];

  @OneToMany(() => Photo, photo => photo.client)
  photos: Photo[];

  @OneToMany(() => Notification, notification => notification.client)
  notifications: Notification[];
}

