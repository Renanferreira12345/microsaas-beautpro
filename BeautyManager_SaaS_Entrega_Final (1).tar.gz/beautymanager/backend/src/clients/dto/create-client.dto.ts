import { IsString, IsOptional, IsEmail, MaxLength, IsNotEmpty, IsDateString } from 'class-validator';

export class CreateClientDto {
  @IsNotEmpty({ message: 'User ID (salon ID) cannot be empty' })
  // user_id will be typically extracted from the authenticated user (salon owner) context, not sent in body for client creation by salon owner.
  // However, if an admin is creating clients for a salon, user_id might be needed.
  // For now, let's assume salon owner creates their own clients, so user_id is implicit.
  // If needed, add @IsInt() user_id: number;

  @IsNotEmpty({ message: 'Client name cannot be empty' })
  @IsString()
  @MaxLength(255)
  name: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  phone?: string;

  @IsOptional()
  @IsEmail({}, { message: 'Please provide a valid email address' })
  @MaxLength(255)
  email?: string;

  @IsOptional()
  @IsDateString()
  date_of_birth?: string; // Using string for DTO, will be converted to Date in service if needed

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsString()
  observations?: string;
}

