import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('subscription_plans')
export class SubscriptionPlan {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 100, unique: true })
  name: string; // e.g., 'Gratuito', 'Premium', 'Pro'

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price_monthly: number;

  @Column({ type: 'integer', nullable: true })
  appointment_limit_monthly: number; // NULL for unlimited

  @Column({ type: 'integer', nullable: true })
  staff_limit: number; // NULL for unlimited

  @Column({ type: 'integer', nullable: true })
  client_limit: number; // NULL for unlimited

  @Column({ type: 'jsonb', nullable: true })
  features: any; // e.g., {"reports_advanced": true, "multi_user": true}

  @Column({ type: 'varchar', length: 255, unique: true, nullable: true })
  stripe_price_id: string;

  @Column({ type: 'boolean', default: true })
  is_active: boolean;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships
  @OneToMany(() => User, user => user.plan)
  users: User[];
}

