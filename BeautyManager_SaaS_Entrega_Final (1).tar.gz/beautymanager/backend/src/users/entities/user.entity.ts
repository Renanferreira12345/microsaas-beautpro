import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToOne } from 'typeorm';
import { SubscriptionPlan } from '../../subscription-plans/entities/subscription-plan.entity'; // Assuming path
import { Client } from '../../clients/entities/client.entity'; // Assuming path
import { Staff } from '../../staff/entities/staff.entity'; // Assuming path
import { Service } from '../../services/entities/service.entity'; // Assuming path
import { Appointment } from '../../appointments/entities/appointment.entity'; // Assuming path
import { Payment } from '../../payments/entities/payment.entity'; // Assuming path
import { StockItem } from '../../stock-items/entities/stock-item.entity'; // Assuming path
import { AutomatedCampaign } from '../../automated-campaigns/entities/automated-campaign.entity'; // Assuming path
import { Notification } from '../../notifications/entities/notification.entity'; // Assuming path
import { Photo } from '../../photos/entities/photo.entity'; // Assuming path

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255 })
  salon_name: string;

  @Column({ type: 'varchar', length: 255 })
  owner_name: string;

  @Column({ type: 'varchar', length: 255, unique: true })
  email: string;

  @Column({ type: 'varchar', length: 255 })
  password_hash: string;

  @ManyToOne(() => SubscriptionPlan, (plan) => plan.users, { nullable: true, onDelete: 'SET NULL', onUpdate: 'CASCADE' })
  plan: SubscriptionPlan;

  @Column({ type: 'varchar', length: 255, unique: true, nullable: true })
  stripe_customer_id: string;

  @Column({ type: 'varchar', length: 50, default: 'inactive' })
  subscription_status: string; // e.g., 'active', 'inactive', 'past_due', 'canceled', 'trialing'

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships
  @OneToMany(() => Client, client => client.user)
  clients: Client[];

  @OneToMany(() => Staff, staff => staff.user)
  staff_members: Staff[];

  @OneToMany(() => Service, service => service.user)
  services: Service[];

  @OneToMany(() => Appointment, appointment => appointment.user)
  appointments: Appointment[];

  @OneToMany(() => Payment, payment => payment.user)
  payments: Payment[];

  @OneToMany(() => StockItem, stockItem => stockItem.user)
  stock_items: StockItem[];

  @OneToMany(() => AutomatedCampaign, campaign => campaign.user)
  automated_campaigns: AutomatedCampaign[];

  @OneToMany(() => Notification, notification => notification.user)
  notifications: Notification[];

  @OneToMany(() => Photo, photo => photo.user)
  photos: Photo[];
}

