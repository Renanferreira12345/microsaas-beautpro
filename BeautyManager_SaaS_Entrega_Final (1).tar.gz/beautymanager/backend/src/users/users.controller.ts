import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, ValidationPipe, ParseIntPipe } from "@nestjs/common";
import { UsersService } from "./users.service";
import { CreateUserDto } from "./dto/create-user.dto";
import { UpdateUserDto } from "./dto/update-user.dto"; // Create this DTO
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"; // Assuming you have this guard
// import { RolesGuard } from '../auth/guards/roles.guard'; // If you implement role-based access
// import { Roles } from '../auth/decorators/roles.decorator'; // If you implement role-based access

@Controller("users")
// @UseGuards(JwtAuthGuard) // Apply to all routes in this controller if needed, or per route
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  // This route is typically public or handled by a specific auth signup route
  // @Post()
  // create(@Body(ValidationPipe) createUserDto: CreateUserDto) {
  //   return this.usersService.createUser(createUserDto);
  // }

  @Get()
  @UseGuards(JwtAuthGuard) // Example: Only authenticated users can list all users (admin role might be better)
  // @Roles('admin') // Example: Only admin can list all users
  findAll() {
    return this.usersService.findAll(); // Implement this method in UsersService
  }

  @Get(":id")
  @UseGuards(JwtAuthGuard) // Example: Only authenticated users can get a user by ID (or self, or admin)
  findOne(@Param("id", ParseIntPipe) id: number) {
    return this.usersService.findOneById(id);
  }

  @Patch(":id")
  @UseGuards(JwtAuthGuard) // Example: Only authenticated users can update their own info (or admin)
  update(@Param("id", ParseIntPipe) id: number, @Body(ValidationPipe) updateUserDto: UpdateUserDto) {
    return this.usersService.update(id, updateUserDto); // Implement this method in UsersService
  }

  @Delete(":id")
  @UseGuards(JwtAuthGuard) // Example: Only admin can delete users
  // @Roles('admin')
  remove(@Param("id", ParseIntPipe) id: number) {
    return this.usersService.remove(id); // Implement this method in UsersService
  }
}

