import { IsString, MinLength, MaxLength, IsEmail, IsNotEmpty, IsOptional } from 'class-validator';

export class CreateUserDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  salon_name: string;

  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  owner_name: string;

  @IsNotEmpty()
  @IsEmail()
  @MaxLength(255)
  email: string;

  @IsNotEmpty()
  @IsString()
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @MaxLength(20, { message: 'Password cannot be longer than 20 characters' })
  // Add regex for password complexity if needed
  password: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  stripe_customer_id?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  subscription_status?: string;

  // plan_id will be handled separately, perhaps after user creation or during subscription
}

