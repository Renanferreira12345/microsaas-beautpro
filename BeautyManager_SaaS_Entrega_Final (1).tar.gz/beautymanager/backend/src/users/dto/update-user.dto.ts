import { IsString, MinLength, MaxLength, IsEmail, IsOptional, IsInt } from 'class-validator';
import { PartialType } from '@nestjs/mapped-types'; // Or @nestjs/swagger if you use it for DTO generation
import { CreateUserDto } from './create-user.dto';

export class UpdateUserDto extends PartialType(CreateUserDto) {
  @IsOptional()
  @IsString()
  @MaxLength(255)
  salon_name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(255)
  owner_name?: string;

  @IsOptional()
  @IsEmail()
  @MaxLength(255)
  email?: string;

  @IsOptional()
  @IsString()
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @MaxLength(20, { message: 'Password cannot be longer than 20 characters' })
  password?: string;

  @IsOptional()
  @IsInt()
  plan_id?: number; // To update the user's plan

  @IsOptional()
  @IsString()
  @MaxLength(255)
  stripe_customer_id?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  subscription_status?: string;
}

