import { Module } from '@nestjs/common';
import { StripeService } from './stripe.service';
import { StripeController } from './stripe.controller';
import { ConfigModule } from '@nestjs/config'; // Import ConfigModule

@Module({
  imports: [ConfigModule], // Add ConfigModule to imports
  providers: [StripeService],
  controllers: [StripeController],
  exports: [StripeService] // Export StripeService if it's used in other modules
})
export class StripeModule {}

