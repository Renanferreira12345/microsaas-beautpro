import { Controller, Post, Req, Res, Headers, Body, HttpStatus, HttpException } from '@nestjs/common';
import { StripeService } from './stripe.service';
import Stripe from 'stripe';

@Controller('stripe')
export class StripeController {
  constructor(private readonly stripeService: StripeService) {}

  @Post('webhook')
  async handleWebhook(@Headers('stripe-signature') sig: string, @Req() req: any, @Res() res: any) {
    let event: Stripe.Event;

    try {
      event = this.stripeService.constructEvent(req.rawBody, sig);
    } catch (err) {
      console.error(`⚠️  Webhook signature verification failed: ${err.message}`);
      return res.status(HttpStatus.BAD_REQUEST).send(`Webhook Error: ${err.message}`);
    }

    // Handle the event
    switch (event.type) {
      case 'invoice.payment_succeeded':
        const invoicePaymentSucceeded = event.data.object as Stripe.Invoice;
        // Then define and call a method to handle the successful payment.
        // handleInvoicePaymentSucceeded(invoicePaymentSucceeded);
        console.log('Invoice payment succeeded:', invoicePaymentSucceeded.id);
        // Update user subscription status in DB, unlock features, etc.
        break;
      case 'invoice.payment_failed':
        const invoicePaymentFailed = event.data.object as Stripe.Invoice;
        // Then define and call a method to handle the failed payment.
        // handleInvoicePaymentFailed(invoicePaymentFailed);
        console.log('Invoice payment failed:', invoicePaymentFailed.id);
        // Notify user, potentially downgrade subscription
        break;
      case 'customer.subscription.updated':
        const customerSubscriptionUpdated = event.data.object as Stripe.Subscription;
        console.log('Subscription updated:', customerSubscriptionUpdated.id);
        // Update subscription details in DB
        break;
      case 'customer.subscription.deleted':
        const customerSubscriptionDeleted = event.data.object as Stripe.Subscription;
        console.log('Subscription deleted:', customerSubscriptionDeleted.id);
        // Update subscription status in DB (e.g., cancelled)
        break;
      // ... handle other event types
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    // Return a 200 response to acknowledge receipt of the event
    res.status(HttpStatus.OK).send();
  }

  @Post('create-checkout-session')
  async createCheckoutSession(@Body() body: { priceId: string; successUrl: string; cancelUrl: string }) {
    const { priceId, successUrl, cancelUrl } = body;
    try {
      const session = await this.stripeService.createCheckoutSession(priceId, successUrl, cancelUrl);
      return { sessionId: session.id };
    } catch (error) {
      console.error('Error creating checkout session:', error);
      throw new HttpException('Failed to create checkout session', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // Example: Endpoint to create a product and price (run once or as needed by admin)
  @Post('create-product-and-price')
  async createProductAndPrice(@Body() body: { productName: string; unitAmount: number; currency: string; recurringInterval: 'month' | 'year' }) {
    const { productName, unitAmount, currency, recurringInterval } = body;
    try {
      const product = await this.stripeService.createProduct(productName);
      const price = await this.stripeService.createPrice(product.id, unitAmount, currency, recurringInterval);
      return { product, price };
    } catch (error) {
      console.error('Error creating product and price:', error);
      throw new HttpException('Failed to create product and price', HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}

