import { Injectable, RawBodyRequest } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';

@Injectable()
export class StripeService {
  private stripe: Stripe;

  constructor(private configService: ConfigService) {
    this.stripe = new Stripe(this.configService.get<string>('STRIPE_SECRET_KEY'), {
      apiVersion: '2024-04-10', // Use the latest API version
    });
  }

  async createCustomer(email: string, name?: string) {
    return this.stripe.customers.create({
      email,
      name,
    });
  }

  async createSubscription(customerId: string, priceId: string) {
    try {
      const subscription = await this.stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });
      return subscription;
    } catch (error) {
      console.error('Error creating subscription:', error);
      throw error;
    }
  }

  async constructEvent(payload: Buffer, sig: string, secret: string) {
    return this.stripe.webhooks.constructEvent(payload, sig, secret);
  }

  async handleWebhookEvent(event: Stripe.Event) {
    // This is a simplified handler. In a real application, you would have more complex logic
    // for each event type, including database updates, sending notifications, etc.
    switch (event.type) {
      case 'invoice.payment_succeeded':
        const invoice = event.data.object as Stripe.Invoice;
        console.log(`PaymentSucceeded: Invoice ${invoice.id} was paid successfully.`);
        // TODO: Update subscription status in your database
        // TODO: Grant access to the service/product
        break;
      case 'invoice.payment_failed':
        const failedInvoice = event.data.object as Stripe.Invoice;
        console.log(`PaymentFailed: Invoice ${failedInvoice.id} payment failed.`);
        // TODO: Notify the user about the payment failure
        // TODO: Potentially suspend access to the service
        break;
      case 'customer.subscription.created':
        const subscriptionCreated = event.data.object as Stripe.Subscription;
        console.log(`SubscriptionCreated: ${subscriptionCreated.id}`);
        // TODO: Store subscription details in your database
        break;
      case 'customer.subscription.updated':
        const subscriptionUpdated = event.data.object as Stripe.Subscription;
        console.log(`SubscriptionUpdated: ${subscriptionUpdated.id}`);
        // TODO: Update subscription details in your database (e.g., plan changes, status changes)
        break;
      case 'customer.subscription.deleted': // Occurs when a subscription is canceled
        const subscriptionDeleted = event.data.object as Stripe.Subscription;
        console.log(`SubscriptionDeleted: ${subscriptionDeleted.id}`);
        // TODO: Update subscription status in your database (e.g., mark as canceled, set end date)
        // TODO: Revoke access at the end of the current billing period if applicable
        break;
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }
  }

  async createCheckoutSession(priceId: string, successUrl: string, cancelUrl: string, customerId?: string) {
    const sessionOptions: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
    };

    if (customerId) {
      sessionOptions.customer = customerId;
    }

    return this.stripe.checkout.sessions.create(sessionOptions);
  }

  async createBillingPortalSession(customerId: string, returnUrl: string) {
    return this.stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });
  }

  // Add other Stripe-related methods as needed
}

