import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
import { Appointment } from '../../appointments/entities/appointment.entity';

@Entity('photos')
export class Photo {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.photos, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @ManyToOne(() => Client, client => client.photos, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  client: Client;

  @ManyToOne(() => Appointment, appointment => appointment.photos, { nullable: true, onDelete: 'SET NULL', onUpdate: 'CASCADE' })
  appointment: Appointment;

  @Column({ type: 'text' })
  photo_url: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  photo_type: string; // e.g., 'antes', 'depois', 'inspiracao'

  @Column({ type: 'text', nullable: true })
  description: string;

  @CreateDateColumn()
  uploaded_at: Date; // Should be CreateDateColumn or have default

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

