import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config'; // Import ConfigService

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const configService = app.get(ConfigService); // Get ConfigService instance

  app.useGlobalPipes(new ValidationPipe());
  app.enableCors(); // Enable CORS for frontend interaction

  const port = configService.get<number>('PORT') || 3000; // Use PORT from .env or default to 3000
  await app.listen(port);
  console.log(`Application is running on: ${await app.getUrl()}`);
}
bootstrap();

