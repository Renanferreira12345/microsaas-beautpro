import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
import { Staff } from '../../staff/entities/staff.entity';
import { Service } from '../../services/entities/service.entity';
import { Photo } from '../../photos/entities/photo.entity'; // Added for relationship
import { Notification } from '../../notifications/entities/notification.entity'; // Added for relationship

@Entity('appointments')
export class Appointment {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.appointments, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @ManyToOne(() => Client, client => client.appointments, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  client: Client;

  @ManyToOne(() => Staff, staff => staff.appointments, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  staff: Staff;

  @ManyToOne(() => Service, service => service.appointments, { onDelete: 'RESTRICT', onUpdate: 'CASCADE' })
  service: Service;

  @Column({ type: 'timestamptz' })
  start_time: Date;

  @Column({ type: 'timestamptz' })
  end_time: Date;

  @Column({ type: 'varchar', length: 50, default: 'scheduled' })
  status: string; // e.g., 'scheduled', 'confirmed', 'completed', 'canceled_by_client', 'canceled_by_salon', 'no_show'

  @Column({ type: 'varchar', length: 50, default: 'pending' })
  payment_status: string; // e.g., 'pending', 'paid_online', 'paid_in_person', 'partially_paid', 'refunded'

  @Column({ type: 'varchar', length: 50, nullable: true })
  payment_method_used: string; // e.g., 'PIX', 'Card', 'Cash'

  @Column({ type: 'text', nullable: true })
  notes_client: string;

  @Column({ type: 'text', nullable: true })
  notes_salon: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;

  // Relationships (as per database model, photos and notifications can be linked to appointments)
  @OneToMany(() => Photo, photo => photo.appointment)
  photos: Photo[];

  @OneToMany(() => Notification, notification => notification.appointment)
  notifications: Notification[];
}

