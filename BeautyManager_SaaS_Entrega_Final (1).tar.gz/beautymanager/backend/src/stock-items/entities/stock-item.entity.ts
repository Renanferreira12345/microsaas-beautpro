import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne } from 'typeorm';
import { User } from '../../users/entities/user.entity';

@Entity('stock_items')
export class StockItem {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, user => user.stock_items, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  user: User; // Represents the salon (User of the SaaS)

  @Column({ type: 'varchar', length: 255 })
  product_name: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  sku: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  category: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  supplier: string;

  @Column({ type: 'integer', default: 0 })
  quantity_on_hand: number;

  @Column({ type: 'integer', default: 0 })
  minimum_stock_level: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  unit_cost: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  unit_price: number;

  @Column({ type: 'date', nullable: true })
  last_restock_date: Date;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

